/**
 * Kanan Patel
 */
var marginScatter = {top: 20, right: 20, bottom: 30, left: 40},
    widthScatter = (800 - marginScatter.left - marginScatter.right) * .5,
    heightScatter = 350 - marginScatter.top - marginScatter.bottom;

/*
 * value accessor - returns the value to encode for a given data object.
 * scale - maps value to a visual display encoding, such as a pixel position.
 * map function - maps from data value to display value
 * axis - sets up axis
 */

// setup x
var xValue = function(d) { return d.Calories;}, // data -> value
    xScale = d3.scale.linear().range([0, widthScatter]), // value -> display
    xMap = function(d) { return xScale(xValue(d));}, // data -> display
    xAxisScatter = d3.svg.axis().scale(xScale).orient("bottom");

// setup y
var yValue = function(d) { return d["Sugars"];}, // data -> value
    yScale = d3.scale.linear().range([heightScatter, 0]), // value -> display
    yMap = function(d) { return yScale(yValue(d));}, // data -> display
    yAxisScatter = d3.svg.axis().scale(yScale).orient("left");

// setup fill color
var cValue = function(d) { return d.Manufacturer;},
    color = d3.scale.category20();

// add the graph canvas to plotB of the webpage
var svgScatter = d3.select(".plotB").append("svg")
    .attr("width", widthScatter + marginScatter.left + marginScatter.right)
    .attr("height", heightScatter + marginScatter.top + marginScatter.bottom)
    .append("g")
    .attr("transform", "translate(" + marginScatter.left + "," + marginScatter.top + ")");

// add the tooltip area to the webpage
var tooltipScatter = d3.select(".plotB").append("div")
    .attr("class", "tooltip")
    .style("opacity", 0);

// load data
d3.csv("data/cereals.csv", function(error, data) {

    data.forEach(function(d) {
        d.Calories = +d.Calories;
        d["Sugars"] = +d["Sugars"];
    });

    xScale.domain([d3.min(data, xValue)-1, d3.max(data, xValue)+1]);
    yScale.domain([d3.min(data, yValue)-1, d3.max(data, yValue)+1]);

    // x-axis
    svgScatter.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(0," + heightScatter + ")")
        .call(xAxisScatter)
        .append("text")
        .attr("class", "label")
        .attr("x", widthScatter)
        .attr("y", -6)
        .style("text-anchor", "end")
        .text("Calories");

    // y-axis
    svgScatter.append("g")
        .attr("class", "y axis")
        .call(yAxisScatter)
        .append("text")
        .attr("class", "label")
        .attr("transform", "rotate(-90)")
        .attr("y", 6)
        .attr("dy", ".71em")
        .style("text-anchor", "end")
        .text("Sugars");

    // draw dots
    svgScatter.selectAll(".dot")
        .data(data)
        .enter().append("circle")
        .attr("class", "dot")
        .attr("r", function(d) {
            return d["Serving Size Weight"] * 5;
        })
        .attr("cx", xMap)
        .attr("cy", yMap)
        .style("fill", function(d) { return color(cValue(d));})
        .on("mouseover", function(d) {
            tooltipScatter.transition()
                .duration(200)
                .style("opacity", .9);
            tooltipScatter.html(d["Cereal Name"] + "<br/> (" + xValue(d)
                + ", " + yValue(d) + ")")
                .style("left", (20) + "px")
                .style("top", (heightScatter) + "px");
        })
        .on("mouseout", function(d) {
            tooltipScatter.transition()
                .duration(500)
                .style("opacity", 0);
        });

    // draw legend
    var legend = svgScatter.selectAll(".legend")
        .data(color.domain())
        .enter().append("g")
        .attr("class", "legend")
        .attr("transform", function(d, i) { return "translate(0," + i * 16 + ")"; });

    // draw legend colored rectangles
    legend.append("rect")
        .attr("x", widthScatter + 15)
        .attr("y", heightScatter - 128)
        .attr("width", 14)
        .attr("height", 14)
        .style("fill", color);

    // draw legend text
    legend.append("text")
        .attr("x", widthScatter + 12)
        .attr("y", heightScatter - 120)
        .attr("dy", ".35em")
        .style("text-anchor", "end")
        .style("font-size", "10px")
        .text(function(d) { return d;})
});
